package in.nit.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import in.nit.model.ProdIdType;
import in.nit.model.Product;

public interface ProductRepo extends JpaRepository<Product, ProdIdType>{

}
