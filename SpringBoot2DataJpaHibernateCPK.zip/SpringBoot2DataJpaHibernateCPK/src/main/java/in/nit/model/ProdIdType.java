package in.nit.model;

import java.io.Serializable;

import javax.persistence.Embeddable;

import lombok.Data;

@Data
@Embeddable
public class ProdIdType implements Serializable {

	public ProdIdType() {
		super();
	}
	public ProdIdType(Integer prodId, Integer venId) {
		super();
		this.prodId = prodId;
		this.venId = venId;
	}
	public Integer getProdId() {
		return prodId;
	}
	public void setProdId(Integer prodId) {
		this.prodId = prodId;
	}
	public Integer getVenId() {
		return venId;
	}
	public void setVenId(Integer venId) {
		this.venId = venId;
	}
	private Integer prodId;
	private Integer venId;
}
