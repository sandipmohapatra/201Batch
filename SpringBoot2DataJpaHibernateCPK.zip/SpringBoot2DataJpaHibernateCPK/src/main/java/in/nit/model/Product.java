package in.nit.model;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;

import lombok.Data;

@Data
@Entity
public class Product {
	@EmbeddedId
	private ProdIdType pid;
	
	public Product() {
		super();
	}
	public Product(ProdIdType pid, String prodCode, Double prodCost, String mfgInfo) {
		super();
		this.pid = pid;
		this.prodCode = prodCode;
		this.prodCost = prodCost;
		this.mfgInfo = mfgInfo;
	}
	public ProdIdType getPid() {
		return pid;
	}
	public void setPid(ProdIdType pid) {
		this.pid = pid;
	}
	public String getProdCode() {
		return prodCode;
	}
	public void setProdCode(String prodCode) {
		this.prodCode = prodCode;
	}
	public Double getProdCost() {
		return prodCost;
	}
	public void setProdCost(Double prodCost) {
		this.prodCost = prodCost;
	}
	public String getMfgInfo() {
		return mfgInfo;
	}
	public void setMfgInfo(String mfgInfo) {
		this.mfgInfo = mfgInfo;
	}
	private String prodCode;
	private Double prodCost;
	private String mfgInfo;
}
