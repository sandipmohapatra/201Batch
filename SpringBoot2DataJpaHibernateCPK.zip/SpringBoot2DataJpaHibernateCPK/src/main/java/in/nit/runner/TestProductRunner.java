package in.nit.runner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import in.nit.model.ProdIdType;
import in.nit.model.Product;
import in.nit.repo.ProductRepo;

@Component
public class TestProductRunner implements CommandLineRunner {
	@Autowired
	private ProductRepo repo;
	
	@Override
	public void run(String... args) throws Exception {
		ProdIdType id = new ProdIdType();
		id.setProdId(10);
		id.setVenId(50);
		
		Product pob=new Product();
		pob.setPid(id);
		pob.setProdCode("PEN");
		pob.setProdCost(560.36);
		pob.setMfgInfo("NIT-HYD");
		
		repo.save(pob);
	}

}


