import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;
@WebServlet("/secondServlet")
public class secondServlet extends HttpServlet
{
public void doGet(HttpServletRequest req,HttpServletResponse res)
{
try
{
res.setContentType("text/html");
PrintWriter pw=res.getWriter();
String s=req.getParameter("t1");
String t=req.getParameter("t2");
pw.println("the user name is "+s);
pw.println("the password is "+t);
}
catch(Exception ae)
{} }}


