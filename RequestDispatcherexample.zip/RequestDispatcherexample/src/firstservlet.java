import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;
@WebServlet("/firstservlet")
public class firstservlet extends HttpServlet
{
public void doGet(HttpServletRequest req,HttpServletResponse res)
{try
{
res.setContentType("text/html");
PrintWriter pw=res.getWriter();
pw.println("Welcome to Request Dispatcher");
RequestDispatcher rd=req.getRequestDispatcher("secondServlet");
rd.include(req,res);
pw.close();
}
catch(Exception ae)
{}}}



