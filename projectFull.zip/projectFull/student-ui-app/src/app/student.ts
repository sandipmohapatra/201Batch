export class Student {
    id: number;
    name: string;
    fee: number;
    course: string;
    email: string;
    addr: string;
}
