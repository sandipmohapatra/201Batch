package com.example.demo;

import org.springframework.stereotype.Component;
//ctrl+shift+O (imports)

@Component("msg")
public class MyMessage { 

	public void welcome() {
		System.out.println("Welcome to first App!");
	}
	public void welcome1() {
		System.out.println("Welcome to first App Batch201!");
	}
}
