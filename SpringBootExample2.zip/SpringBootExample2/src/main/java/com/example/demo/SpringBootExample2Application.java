package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class SpringBootExample2Application {

	public static void main(String[] args) {
		ApplicationContext ac=SpringApplication.run(SpringBootExample2Application.class, args);
		MyMessage obj=(MyMessage) ac.getBean("msg");
		obj.welcome();
		obj.welcome1();
		MyMessage2 obj1=(MyMessage2) ac.getBean("stud");
		obj1.input();
		obj1.display();
			}
}
