package com.example.demo;

import org.springframework.stereotype.Component;
import java.util.*;
//ctrl+shift+O (imports)

@Component("stud")
public class MyMessage2 
{ 
int rollno;
String name,address;
void input()
{
	Scanner ob=new Scanner(System.in);
	System.out.println("enter rollno,name,address");
	rollno=ob.nextInt();
	name=ob.next();
	address=ob.next();
}
void display()
{
	System.out.println("rollno :"+rollno);
	System.out.println("name :"+name);
	System.out.println("address :"+address);
	}
	
}
