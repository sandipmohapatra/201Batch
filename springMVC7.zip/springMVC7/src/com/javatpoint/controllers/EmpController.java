package com.javatpoint.controllers;

import java.util.ArrayList;
import java.util.List;
import java.sql.*;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.javatpoint.beans.Emp;

@Controller
public class EmpController {
Emp emp=new Emp();
	@RequestMapping("/empform1")
	public ModelAndView showform(){
		return new ModelAndView("empform","command",new Emp());
	}
	
	@RequestMapping(value="/save",method = RequestMethod.POST)
	public ModelAndView save(@ModelAttribute("emp") Emp emp)
	{
		try
		{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","System","1234");
		PreparedStatement st=con.prepareStatement("insert into  employee values(?,?,?,?)");
			System.out.println(emp.getId()+" "+emp.getName()+" "+emp.getSalary()+" "+emp.getDesignation());
			st.setString(1,emp.getId());
			st.setString(2,emp.getName());
			st.setString(3,emp.getSalary());
			st.setString(4,emp.getDesignation());
			st.execute();
		}
		catch(Exception ae)
		{
			ae.printStackTrace();
		}
		return new ModelAndView("redirect:/viewemp");
	}
	
	@RequestMapping("/viewemp")
	public ModelAndView viewemp(){
				
			return new ModelAndView("viewemp");
	}
}




