package com.jspiders.hibernate.tester;

import com.jspiders.hibernate.dao.UFODAO;
import com.jspiders.hibernate.dto.UFODTO;

public class AppTester {

	public static void main(String[] args) {
		UFODTO dto = new UFODTO();
		dto.setUfoId(22);
		dto.setShape("cylinder1");
		dto.setSpeed(1000.798);
		dto.setColour("green and red");
		System.out.println(dto);
		
		UFODAO dao = new UFODAO();
		dao.saveUFO(dto);
		
	}

}
