import { Component, OnInit } from '@angular/core';
import { Bookabed } from '../bookabed';
import { BookabedService } from '../bookabed.service';

@Component({
  selector: 'app-bookabed',
  templateUrl: './bookabed.component.html',
  styleUrls: ['./bookabed.component.css']
})
export class BookabedComponent implements OnInit {

  bookabed: Bookabed;
  // message to ui
  message: string;

  // inject service class
  constructor(private service: BookabedService) { }

  ngOnInit(): void {
    // when page is loaded clear form data
    this.bookabed = new Bookabed();
  }

  // tslint:disable-next-line: typedef
  createbookabed() {
    this.service.createBookabed(this.bookabed)
    .subscribe(data => {
      this.message = data; // read message
      this.bookabed = new Bookabed(); // clear form
    }, error => {
      console.log(error);
    });


 }
}
