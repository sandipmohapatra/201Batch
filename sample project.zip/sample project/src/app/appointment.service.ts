import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Appointment } from './appointment';


@Injectable({
  providedIn: 'root'
})

  export class AppointmentService {

    private basePath = 'http://localhost:8090/rest/appointment';
  
    constructor(private http: HttpClient) { }
  
  
    getAllAppointments(): Observable<Appointment[]> {
      return this.http.get<Appointment[]>(`${this.basePath}/all`);
    }
  
    deleteOneAppointment(id: number): Observable<any> {
      return this.http.delete(`${this.basePath}/remove/${id}`, {responseType: 'text'});
    }
  
    createAppointment(appointment: Appointment): Observable<any> {
      return this.http.post(`${this.basePath}/save`, appointment, {responseType: 'text'});
    }
  
    getOneAppointment(id: number): Observable<Appointment> {
      return this.http.get<Appointment>(`${this.basePath}/one/${id}`);
    }
  
    updateAppointment(id: number, appointment: Appointment): Observable<any> {
      return this.http.put(`${this.basePath}/modify/${id}`, appointment, {responseType : 'text'});
    }
  
  
}
