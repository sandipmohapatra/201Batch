
export class Vaccination {
    id: number;
    name: string;
    aadhar: string;
    contacts: string;
    dose: string;
    vaccine: string;
    date2: string;
    city: string;
    timeslot1: string;
}