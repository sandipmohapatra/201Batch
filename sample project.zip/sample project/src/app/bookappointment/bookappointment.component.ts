import { Component, OnInit } from '@angular/core';
import { Bookappointment } from '../bookappointment';
import { BookappointmentService } from '../bookappointment.service';

@Component({
  selector: 'app-bookappointment',
  templateUrl: './bookappointment.component.html',
  styleUrls: ['./bookappointment.component.css']
})
export class BookappointmentComponent implements OnInit {

  bookappointment: Bookappointment;
  // message to ui
  message: string;

  // inject service class
  constructor(private service: BookappointmentService) { }

  ngOnInit(): void {
    // when page is loaded clear form data
    this.bookappointment = new Bookappointment();
  }

  // tslint:disable-next-line: typedef
  createbookappointment() {
    this.service.createBookappointment(this.bookappointment)
    .subscribe(data => {
      this.message = data; // read message
      this.bookappointment = new Bookappointment(); // clear form
    }, error => {
      console.log(error);
    });


 }
}
