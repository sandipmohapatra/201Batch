import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Vaccination } from './vaccination';


@Injectable({
  providedIn: 'root'
})

  export class VaccinationService {

    private basePath = 'http://localhost:8090/rest/vaccination';
  
    constructor(private http: HttpClient) { }
  
  
    getAllVaccinations(): Observable<Vaccination[]> {
      return this.http.get<Vaccination[]>(`${this.basePath}/all`);
    }
  
    deleteOneVaccination(id: number): Observable<any> {
      return this.http.delete(`${this.basePath}/remove/${id}`, {responseType: 'text'});
    }
  
    createVaccination(vaccination: Vaccination): Observable<any> {
      return this.http.post(`${this.basePath}/save`, vaccination, {responseType: 'text'});
    }
  
    getOneVaccination(id: number): Observable<Vaccination> {
      return this.http.get<Vaccination>(`${this.basePath}/one/${id}`);
    }
  
    updateVaccination(id: number, vaccination: Vaccination): Observable<any> {
      return this.http.put(`${this.basePath}/modify/${id}`, vaccination, {responseType : 'text'});
    }
  
  
}
