import { Component, OnInit } from '@angular/core';
import { Vaccination } from '../vaccination';
import { VaccinationService } from '../vaccination.service';

@Component({
  selector: 'app-vaccination',
  templateUrl: './vaccination.component.html',
  styleUrls: ['./vaccination.component.css']
})
export class VaccinationComponent implements OnInit {

  vaccination: Vaccination;
  // message to ui
  message: string;

  // inject service class
  constructor(private service: VaccinationService) { }

  ngOnInit(): void {
    // when page is loaded clear form data
    this.vaccination = new Vaccination();
  }

  // tslint:disable-next-line: typedef
  createVaccination() {
    this.service.createVaccination(this.vaccination)
    .subscribe(data => {
      this.message = data; // read message
      this.vaccination = new Vaccination(); // clear form
    }, error => {
      console.log(error);
    });


 }
}
