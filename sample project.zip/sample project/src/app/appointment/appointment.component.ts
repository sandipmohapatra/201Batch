import { Component, OnInit } from '@angular/core';
import { Appointment } from '../appointment';
import { AppointmentService } from '../appointment.service';


@Component({
  selector: 'app-appointment',
  templateUrl: './appointment.component.html',
  styleUrls: ['./appointment.component.css']
})
export class AppointmentComponent implements OnInit {

  appointment: Appointment;
  // message to ui
  message: string;

  // inject service class
  constructor(private service: AppointmentService) { }

  ngOnInit(): void {
    // when page is loaded clear form data
    this.appointment = new Appointment();
  }

  // tslint:disable-next-line: typedef
  createAppointment() {
    this.service.createAppointment(this.appointment)
    .subscribe(data => {
      this.message = data; // read message
      this.appointment = new Appointment(); // clear form
    }, error => {
      console.log(error);
    });


 }

}
