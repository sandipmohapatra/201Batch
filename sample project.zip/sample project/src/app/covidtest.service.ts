import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Covidtest } from './covidtest';


@Injectable({
  providedIn: 'root'
})

  export class CovidtestService {

    private basePath = 'http://localhost:8090/rest/covidtest';
  
    constructor(private http: HttpClient) { }
  
  
    getAllCovidtests(): Observable<Covidtest[]> {
      return this.http.get<Covidtest[]>(`${this.basePath}/all`);
    }
  
    deleteOneCovidtest(id: number): Observable<any> {
      return this.http.delete(`${this.basePath}/remove/${id}`, {responseType: 'text'});
    }
  
    createCovidtest(covidtest: Covidtest): Observable<any> {
      return this.http.post(`${this.basePath}/save`, covidtest, {responseType: 'text'});
    }
  
    getOneCovidtest(id: number): Observable<Covidtest> {
      return this.http.get<Covidtest>(`${this.basePath}/one/${id}`);
    }
  
    updateCovidtest(id: number, covidtest: Covidtest): Observable<any> {
      return this.http.put(`${this.basePath}/modify/${id}`, covidtest, {responseType : 'text'});
    }
  
  
}
