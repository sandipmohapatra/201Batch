import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FeedbackComponent } from './feedback/feedback.component';
import { BookabedComponent } from './bookabed/bookabed.component'
import { BookappointmentComponent } from './bookappointment/bookappointment.component'
import { AmbulanceComponent } from './ambulance/ambulance.component';
import { CovidtestComponent } from './covidtest/covidtest.component';
import { VaccinationComponent } from './vaccination/vaccination.component';
import { AppointmentComponent } from './appointment/appointment.component';
import { AboutusComponent } from './aboutus/aboutus.component';

const routes: Routes = [

  {path: 'feedback', component: FeedbackComponent},
  {path: '', redirectTo: 'feedback', pathMatch: 'full'},
  {path: 'bookabed', component: BookabedComponent},
  {path: '', redirectTo: 'bookabed', pathMatch: 'full'},
  {path: 'bookappointment', component: BookappointmentComponent},
  {path: '', redirectTo: 'bookappointment', pathMatch: 'full'},
  {path: 'ambulance', component: AmbulanceComponent},
  {path: '', redirectTo: 'ambulance', pathMatch: 'full'},
  {path: 'covidtest', component: CovidtestComponent},
  {path: '', redirectTo: 'covidtest', pathMatch: 'full'},
  {path: 'vaccination', component: VaccinationComponent},
  {path: '', redirectTo: 'vaccination', pathMatch: 'full'},
  {path: 'appointment', component: AppointmentComponent},
  {path: '', redirectTo: 'appointment', pathMatch: 'full'},
  {path: 'aboutus', component: AboutusComponent},
  {path: '', redirectTo: 'aboutus', pathMatch: 'full'},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
