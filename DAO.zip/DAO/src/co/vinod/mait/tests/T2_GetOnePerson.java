package co.vinod.mait.tests;

import co.vinod.mait.dao.DaoException;
import co.vinod.mait.dao.PersonDao;
import co.vinod.mait.dao.impl.JdbcPersonDao;
import co.vinod.mait.entity.Person;

public class T2_GetOnePerson {

	public static void main(String[] args) throws DaoException {
		
		PersonDao dao = new JdbcPersonDao();
		
		int id = 101;
		Person p = dao.getPerson(id);
		if(p==null){
			System.out.println("No data found");
		}
		else {
			System.out.println(p);
		}
		
	}
}
