package co.vinod.mait.tests;

import java.util.List;

import co.vinod.mait.dao.DaoException;
import co.vinod.mait.dao.PersonDao;
import co.vinod.mait.dao.impl.JdbcPersonDao;
import co.vinod.mait.entity.Person;

public class T3_GetAllPersons {

	public static void main(String[] args) throws DaoException {
		PersonDao dao = new JdbcPersonDao();

		List<Person> list = dao.getAllPersons();
		for (Person p : list) {
			System.out.println(p.getFirstName() 
					+ " " + p.getLastName());
		}
	}

}
