package co.vinod.mait.tests;

import co.vinod.mait.dao.DaoException;
import co.vinod.mait.dao.PersonDao;
import co.vinod.mait.dao.impl.JdbcPersonDao;
import co.vinod.mait.entity.Person;

public class T1_AddPerson {

	public static void main(String[] args) throws DaoException {

		Person person = new Person(101, "Sandip", "Kumar", "9731424784",
				"sandip@gmail.com");

		PersonDao dao = new JdbcPersonDao();
		dao.addPerson(person);
		System.out.println("Person data added to db.");
		
	}
}
