package co.vinod.mait.dao;

import java.util.List;

import co.vinod.mait.entity.Person;

public interface PersonDao {

	// CRUD operations
	
	public void addPerson(Person person) throws DaoException;
	public Person getPerson(int id) throws DaoException;
	public void updatePerson(Person person) throws DaoException;
	public void deletePerson(int id) throws DaoException;
	
	// Queries
	
	public List<Person> getAllPersons() throws DaoException;
	public Person getPersonByPhone(String phone) throws DaoException;
	
}
