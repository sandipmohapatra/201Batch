package in.nit;

import org.springframework.stereotype.Component;
//ctrl+shift+O (imports)

@Component("msg")
public class MyMessage { 

	public void welcome() {
		System.out.println("Welcome to first App!");
	}
}
